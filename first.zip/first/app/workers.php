<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class workers extends Model
{
    //
}
