<?php $__env->startSection('title'); ?>
    Страница добавления / редактирования сотрудника
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Сотрудники компании</h1>
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route('add-form')); ?>" method="post">
        <div class="form-group">
            <label for="name">Имя</label>
            <input type="text" name="name" id="name" value="<?php echo e(isset($data) ? $data->name : old('name')); ?>" class="form-control" placeholder="Укажите имя">
        </div>
        <div class="form-group">
            <label for="date">Дата рождения</label>
            <input type="date" name="date" id="date" value="<?php echo e(isset($data) ? $data->date : old('date')); ?>" class="form-control">
        </div>
        <div class="form-group">
            <label for="prof">Должность</label>
            <input type="text" name="prof" id="prof" value="<?php echo e(isset($data) ? $data->prof : old('prof')); ?>" class="form-control" placeholder="Укажите должность">
        </div>
        <input type="hidden" name="_token" value="<?php echo e(@csrf_token()); ?>">
        <input type="hidden" name="action" value="<?php echo e(isset($data) ? 'edit' : 'add'); ?>">
        <?php if(isset($data)): ?>
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
        <?php endif; ?>
        <button type="submit" class="btn btn-success"><?php echo e(isset($data) ? 'Сохранить' : 'Добавить'); ?></button>
        <a href="<?php echo e(route('main')); ?>"><div type="button" class="btn btn-link">Вернуться</div></a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>