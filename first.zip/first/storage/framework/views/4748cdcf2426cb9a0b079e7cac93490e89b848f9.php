<?php $__env->startSection('title'); ?>
Главная страница
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Сотрудники компании</h1>
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="btn-group mb-3">
        <a href="/add"><div class="btn btn-success">Добавить сотрудника</div></a>
    </div>

    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th>#</th>
            <th>Имя</th>
            <th>Должность</th>
            <th>Дата рождения</th>
            <th>Действия</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $i = 1;
        ?>

        <?php if(@count($data) == 0): ?>
            <tr><td colspan="5" class="text-center">Список пуст.</td></tr>
        <?php endif; ?>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($i); ?></th>
                <td><?php echo e($el->name); ?></td>
                <td><?php echo e($el->prof); ?></td>
                <td><?php echo e($el->date); ?></td>
                <td>
                    <a href="<?php echo e(route('edit', $el->id)); ?>">Редактировать</a> &nbsp;
                    <a href="<?php echo e(route('delete', $el->id)); ?>" onclick="conf(this, 'Действительно удалить?');return false;">Удалить</a>
                </td>
            </tr>
            <?php
            $i++
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>